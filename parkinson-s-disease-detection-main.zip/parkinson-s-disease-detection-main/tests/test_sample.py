#  Project : Detection of Parkinson's Disease Using Vocal Features: An Eigen Approach
#  Filename : test_sample.py
#  Author : thameem
#  Modified time : Thu, 24 Nov 2022 at 12:27 am India Standard Time

def test_sample():
    pass
